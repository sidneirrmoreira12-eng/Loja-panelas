import { useState } from "react";

export default function App() {
  const [produtos, setProdutos] = useState([]);
  const [admin, setAdmin] = useState(false);
  const [senha, setSenha] = useState("");
  const [cart, setCart] = useState([]);

  function login() {
    if (senha === "1234") setAdmin(true);
  }

  function adicionarProduto() {
    const nome = prompt("Nome do produto:");
    const preco = prompt("Preço:");
    const imagem = prompt("URL da imagem (ou selecione depois):");

    setProdutos([...produtos, { nome, preco, imagem }]);
  }

  function adicionarAoCarrinho(p) {
    setCart([...cart, p]);
  }

  function finalizarCompra() {
    const msg = cart
      .map((p) => `• ${p.nome} - R$${p.preco}`)
      .join("%0A");

    const url = `https://wa.me/5511999999999?text=Quero%20finalizar%20a%20compra:%0A${msg}`;
    window.open(url, "_blank");
  }

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4 text-center">Loja de Panelas</h1>

      {!admin && (
        <div className="bg-white p-4 shadow rounded mb-4">
          <h2 className="font-bold mb-2">Login Admin</h2>
          <input
            type="password"
            className="border p-2 w-full mb-2"
            placeholder="Senha: 1234"
            onChange={(e) => setSenha(e.target.value)}
          />
          <button onClick={login} className="bg-blue-500 text-white p-2 w-full rounded">
            Entrar
          </button>
        </div>
      )}

      {admin && (
        <button
          onClick={adicionarProduto}
          className="bg-green-600 text-white p-2 rounded mb-4 w-full"
        >
          Adicionar Produto
        </button>
      )}

      <div className="grid grid-cols-2 gap-4">
        {produtos.map((p, i) => (
          <div key={i} className="bg-white p-3 shadow rounded">
            <img
              src={p.imagem}
              alt="produto"
              className="w-full h-32 object-cover rounded"
            />
            <h3 className="font-bold mt-2">{p.nome}</h3>
            <p>R$ {p.preco}</p>
            <button
              onClick={() => adicionarAoCarrinho(p)}
              className="bg-orange-500 text-white w-full mt-2 p-2 rounded"
            >
              Comprar
            </button>
          </div>
        ))}
      </div>

      {cart.length > 0 && (
        <button
          onClick={finalizarCompra}
          className="fixed bottom-4 right-4 bg-green-600 text-white p-3 rounded-full shadow-xl"
        >
          Finalizar no WhatsApp
        </button>
      )}
    </div>
  );
}